from electrum.i18n import _

fullname = 'GreenAddress instant'
description = _("Allows validating if your transactions have instant confirmations by GreenAddress")
available_for = ['qt']
